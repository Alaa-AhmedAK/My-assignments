import random

class Card(object):
    def __init__(self, suit, value):
        self.suit = suit
        self.value = value

    def show(self):
        print(f"{self.value} of {self.suit}")


class Deck(object):
    def __init__(self):
        self.cards = []
        self.build()

    def build(self):
        for s in ["Spades", "Clubs", "Diamonds", "Hearts"]:
            for v in range(1, 14):
                self.cards.append(Card(s, v))

    def shuffle(self):
        for i in range(len(self.cards) - 1, 0, -1):
            rand = random.randint(0, i)
            self.cards[i], self.cards[rand] = self.cards[rand], self.cards[i]

    def drawCard(self):
        return self.cards.pop()


class Player(object):
    def __init__(self, name):
        self.hand = []
        self.name = name

    def draw(self, deck):
        self.hand.append(deck.drawCard())
        return self

    def showHand(self):
        for card in self.hand:
            card.show()

    def discard(self):
        return self.hand.pop()

    def handValue(self):
        return sum(card.value for card in self.hand)



def play_game(player1, player2, deck):
    deck.shuffle()

    player1.draw(deck).draw(deck)
    player2.draw(deck).draw(deck)

    print(f"\n{player1.name}'s hand:")
    player1.showHand()
    print(f"Total value: {player1.handValue()}")

    print(f"\n{player2.name}'s hand:")
    player2.showHand()
    print(f"Total value: {player2.handValue()}")


    if player1.handValue() > player2.handValue():
        print(f"\n{player1.name} wins!")
    elif player1.handValue() < player2.handValue():
        print(f"\n{player2.name} wins!")
    else:
        print("\nIt's a tie!")


deck = Deck()
player1 = Player("Ala'a")
player2 = Player("Fatima")


play_game(player1, player2, deck)
